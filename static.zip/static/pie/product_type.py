import matplotlib.pyplot as plt

sizes = ([779,157],[1939,382],[1942,241],[2576,75],[2250,1137],[2550,1376],[2210,67],[1733,617],[1313,501],[607,282],[481,3553],[150,456])
labels = ['Investment', 'OwnerOccupier']
colors = ['#803815','#D48C6A']
explode = (0, 0.1)

for n,y in enumerate(sizes):
    fig1, ax1 = plt.subplots()
    patches,l_text,p_text = ax1.pie( y, explode=explode, labels=labels, colors=colors, autopct='%1.1f%%',shadow=True, startangle=90)
# Equal aspect ratio ensures that pie is drawn as a circle
    for t in l_text:
        t.set_size(15)
    for t in p_text:
        t.set_size(20)
    ax1.axis('equal')
    plt.savefig(".\pie_type_{:d}.png".format(n+1))